function pop=CreateInitialPopulation(pop,Dim,Ub,Lb)

for i=1:size(pop,1)
    pop(i).position=Lb+(Ub-Lb).*rand(1,Dim);
    pop(i).cost=Fun(pop(i).position,Dim);
end


