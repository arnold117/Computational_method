function [best,fmin] = mainfile()
clc
clear all
close all

disp(['CPA is solving 100D Step test function.'])
disp(['Please wait...'])
disp(blanks(1)');

tic
%100D step test function variables
d=100;
Lb=-5.12*ones(1,d);
Ub=5.12*ones(1,d);
opt=zeros(d,1);
tol=1e-05;

%Carnivorous Plant Algorithm
[best,fmin]=CPA(Lb,Ub,d,opt,tol);











