% Objective function
function z=Fun(u,d)

z1 = 0;
for ii = 1:d
    xi = u(ii);
    z1 = z1 + (xi+0.5)^2;
end
z = z1;
